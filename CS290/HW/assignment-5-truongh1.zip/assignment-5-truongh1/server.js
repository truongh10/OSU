/*
 * Write your routing code in this file.  Make sure to add your name and
 * @oregonstate.edu email address below.
 *
 * Name: Hao Truong
 * Email: truongh@oregonstate.edu
 */

var path = require('path');
var express = require('express');
var exphbs = require('express-handlebars')
var twitData = require('./twitData.json')



var app = express();
var port = process.env.PORT || 3000;

app.engine('handlebars', exphbs({ defaultLayout: 'main' }))
app.set('view engine', 'handlebars')

app.use(express.static('public'));


app.get(['/','/twits'], function(req,res) {


  // res.status(200).render('twitPage', {
  //   text: 'hello sajbaj',
  //   author: 'Hao'
  // })i
  
  res.status(200).render('twitPage', {twits: twitData})


})

app.get('/twits/:index', function(req,res,next) {
  var index = req.params.index
  // console.log(typeof index)
  console.log('== index:', parseInt(index))
  console.log(twitData[parseInt(index)])
  if(twitData[parseInt(index)]) {

    res.status(200).render('twitPage', {twits: [{text: twitData[parseInt(index)].text, author: twitData[parseInt(index)].author}]} )
  }
  else {
    next()
  }
})



app.get('*', function (req, res) {
  res.status(404).render('404', {
    page: req.url
  })
});

app.listen(port, function () {
  console.log("== Server is listening on port", port);
});
