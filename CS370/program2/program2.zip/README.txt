To run the program: python3 hao_truong_bloom_filter -d dictionary.txt -i input.txt -o3 output3.txt -o5 output5.txt
