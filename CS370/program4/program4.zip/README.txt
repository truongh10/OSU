1. To generate qrcode:
		python3 truong-MP4.py --generate-qr

2. To generate opt:
		python3 truong-MP4.py --get-opt