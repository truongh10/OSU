To complile:
	python3 hw3-2.py text.txt

text.txt contains the plaintext to encrypt