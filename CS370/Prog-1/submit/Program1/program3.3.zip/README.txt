To compile:

	python3 free-collision.py
	python3 wk-collision.py

