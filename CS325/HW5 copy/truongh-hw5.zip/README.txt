
	To compile: gcc -std=gnu99 -o mst mst.c -lm
	To tun:		./mst
