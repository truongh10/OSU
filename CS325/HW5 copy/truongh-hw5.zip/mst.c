#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include <math.h>
#include <stdbool.h>
#include <limits.h>


typedef struct Vertices {
	int x;		// x position
	int y;		// y position
}Vertices;


// this function calculate distance between 2 vertices
int distance(int x1, int y1, int x2, int y2) {
	double dist = 0;	//distance between two vertices
	double temp = (x1 - x2)*(x1 - x2) + (y1 - y2)*(y1 - y2);
	dist = sqrt(temp);	// compute distance
	if ((dist - (int)dist) < 0.5)	// if the tenth place is less than 5
		return (int)dist;	// round it down and return
	else				// if the tenth place is greater than 5
		return (int)dist + 1;	// round it up and return
}	


// this function finds the vertex with smallest key
// that is not included in MST and returns its index
//https://www.geeksforgeeks.org/prims-minimum-spanning-tree-mst-greedy-algo-5/
// I referred to this website to achieved this function
int ExtractMin(int V, int key[], bool isIncluded[]) {
	int index;	
	int temp = INT_MAX;
	for (int i = 0; i < V; i++) {	// for every vertex 
		if (!isIncluded[i] && key[i] < temp) {	// if it's not in MST and its key is less than INT_MAX
			index = i;
			temp = key[i];
		}
	}
	return index;
}



// this function finds the MST from the given adjacency matrix
// this function takes 4 inputs, number of vertices V, adjacency matrix, a set of vertices, and starting vertex
// It will print the total distance from the MST
void MST_Prim(int V, int G[V][V], Vertices vertices[], int r) {
	int key[V];	// holds the key value of each vertex
	int totalDistance = 0;	
	// assign each key to INT_MAX... a maximum number that an int can hold
	for (int i = 0; i < V; i++)
		key[i] = INT_MAX;
	
	bool isIncluded[V];	// keep track of included vertices in MST
	// initialize vertices to false since no vertices are included in MST yet
	for (int i = 0; i < V; i++)
		isIncluded[i] = false;

	int p[V];	// store parents of vertices
	p[r] = -1;	// the parent of the starting vertex is -1 which means undefined
	key[r] = 0;	// set the starting vertex to 0 

	int n = 0;	
	while (n < V) {	// loop V times
		int u = ExtractMin(V, key, isIncluded);	// get the vertex with smallest key that is not in MST
		isIncluded[u] = true;	// add vertex to MST

		// for each vertex, if it's not in MST and its distance
		// is smaller than infinity, update parent and
		// set key value to that distance
		for (int v = 0; v < V; v++) {
			if (!isIncluded[v] && G[u][v]) {
				if (G[u][v] < key[v]) {
					p[v] = u;
					key[v] = G[u][v];
				}
			}
		}
		n++;
	}

	// print edges in MST and distance
	printf("Edges in MST\n");
	printf("Point (x,y)		Distance\n");
	for (int i = 1; i < V; i++) {
		int u = i;
		int v = p[i];
		totalDistance += G[u][v];
		printf("(%d,%d) - (%d,%d)		%d\n", vertices[u].x,vertices[u].y,vertices[v].x,vertices[v].y, G[u][v]);
	}
	printf("	Total distance %d\n", totalDistance);	
}


int main() {
	int temp;
	int testNum;	// holds number of test cases
	int V;		// holds number of vertices
	

	FILE *file = fopen("graph.txt", "r");	// open file for reading
	
	// read the file
	// first line is the number of test cases
	fscanf(file, "%d", &testNum);
	
	for (int i = 0; i < testNum; i++) { 	// for each test case
		fscanf(file, "%d", &V);		// next number is number of vertices
		Vertices vertices[V];		// hold all vertices from graph
		int graph[V][V];		// adjacent matrix
		for (int j =0; j < V; j++) {
			fscanf(file, "%d", &temp);	// read x coordinate of vertex
			vertices[j].x = temp;
			fscanf(file, "%d", &temp);	// read y coordinate of vertex
			vertices[j].y = temp;
		}
		// fill up the adjacent matrix 
		for (int k = 0; k < V; k ++) {
			for (int v = 0; v < V; v++) {
				if (vertices[k].x == vertices[v].x && vertices[k].y == vertices[v].y) {
					graph[k][v] = 0;
				}
				else {
					graph[k][v] = distance(vertices[k].x,vertices[k].y,vertices[v].x,vertices[v].y);
				}
			}
		}
		
/*		// print graph
		for (int k = 0; k < V; k ++) {
			for (int v = 0; v < V; v++) {
				printf("%d ", graph[k][v]);
			}
			printf("\n");
		}
*/
		int i = 0;
		printf("Test case %d\n", ++i);
		MST_Prim(V,graph,vertices,0);
		printf("\n\n");
	}

	return 0;
}



















