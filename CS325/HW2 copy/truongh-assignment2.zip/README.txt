
	1. For mergeSort3.c:
		To compile: gcc -std=gnu99 -o mergeSort3 mergeSort3.c
		To run: mergeSort3

	2. For mergesort3Time.c:
		To compile: gcc -std=gnu99 -o mergesort3Time mergesort3Time.c
		To run: mergesort3Time
		

