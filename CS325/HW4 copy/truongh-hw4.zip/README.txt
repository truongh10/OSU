	To compile: gcc -std=gnu99 hw4.c

	To run:	.\a.out
