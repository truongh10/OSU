	
	1. To compile knapsack.c:
		gcc -std=gnu99 -o knapsack knapsack.c
	2. To run knapsack:
		./knapsack
	3. To compile shopping.c:
		gcc -std=gnu99 -o shopping shopping.c
	4. To run shopping:
		./shopping
