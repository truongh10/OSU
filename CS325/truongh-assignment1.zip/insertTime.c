#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>


void insertSort(int array[], int size) {
	for (int i = 1; i < size; i++) {
		int j = i;

		while(j >= 0 && array[j - 1] > array[j]) {
			int temp = array[j - 1];
			array[j - 1] = array[j];
			array[j] = temp;
			j--;
		}
	}
//	for (int i = 0; i < size; i++) {
//		printf("%d ", array[i]);
//	}
//	printf("\n");
}


int main() {
	srand(time(NULL));
	
	for (int i = 5000; i <= 50000; i += 5000) {
		int array[i];
		for (int j = 0; j < i; j++) {
			array[j] = rand() % 10000 + 1;
		}
		clock_t t;
		t = clock();
		insertSort(array, i);
		t = clock() - t;
		double time_taken = ((double)t)/CLOCKS_PER_SEC;
		printf("size = %d, time = %f\n", i, time_taken);
	}

	return 0;
}


































