#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include <string.h>

void merge(int * array, int start, int mid, int end) {
	int temp[end - start + 1];	
	int k = 0;
	int leftIndex = start, rightIndex = mid + 1;
	// loop through the left half and right half of array and
	// add smaller numbers to temp array
	while (leftIndex <= mid && rightIndex <= end) {
		if (array[leftIndex] <= array[rightIndex]) {
			temp[k] = array[leftIndex];
			leftIndex++;
		} else {
			temp[k] = array[rightIndex];
			rightIndex++;
		}
		k++;
	}
	// add leftover numbers from half left to temp array
	while (leftIndex <= mid) {
		temp[k] = array[leftIndex];
		k++;
		leftIndex++;
	}
	// add leftover numbers from half right to temp array
	while (rightIndex <= end) {
		temp[k] = array[rightIndex];
		k++;
		rightIndex++;
	}
	//copy temp array to original array
	for (int i = start; i <= end; i++) {
		array[i] = temp[i-start];
	}
}

void mergeSort(int* array, int start, int end) {
	if (start < end) {
		int mid = (start + end) / 2;
		mergeSort(array, start, mid);
		mergeSort(array, mid+1, end);
		merge(array, start, mid, end);
	}
}




int main() {
	srand(time(NULL));
	
	for (long int i = 100000; i <= 1000000; i += 100000) {
		int array[i];
		for (long int j = 0; j < i; j++) {
			array[j] = rand() % 10000 + 1;
		}
		clock_t t;
		t = clock();
		mergeSort(array, 0, i - 1);
		t = clock() - t;
		double time_taken = ((double)t)/CLOCKS_PER_SEC;
		printf("size = %d, time = %f\n", i, time_taken);
	}

	return 0;
}


































