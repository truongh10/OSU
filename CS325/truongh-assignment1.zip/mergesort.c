#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include <string.h>

void merge(int * array, int start, int mid, int end) {
	int temp[end - start + 1];	
	int k = 0;
	int leftIndex = start, rightIndex = mid + 1;
	// loop through the left half and right half of array and
	// add smaller numbers to temp array
	while (leftIndex <= mid && rightIndex <= end) {
		if (array[leftIndex] <= array[rightIndex]) {
			temp[k] = array[leftIndex];
			leftIndex++;
		} else {
			temp[k] = array[rightIndex];
			rightIndex++;
		}
		k++;
	}
	// add leftover numbers from half left to temp array
	while (leftIndex <= mid) {
		temp[k] = array[leftIndex];
		k++;
		leftIndex++;
	}
	// add leftover numbers from half right to temp array
	while (rightIndex <= end) {
		temp[k] = array[rightIndex];
		k++;
		rightIndex++;
	}
	//copy temp array to original array
	for (int i = start; i <= end; i++) {
		array[i] = temp[i-start];
	}
}

void mergeSort(int* array, int start, int end) {
	if (start < end) {
		int mid = (start + end) / 2;
		mergeSort(array, start, mid);
		mergeSort(array, mid+1, end);
		merge(array, start, mid, end);
	}
}



int main() {
	
	char *currLine = NULL;
	char* saveptr, *token;	// for reading data.txt file
	int length = 0;	// stores the size of array
	size_t len = 0;
	ssize_t nread;

	// open data.txt file
	FILE *dataFile = fopen("data.txt", "r");
	//read the file line by line
	while ((nread = getline(&currLine, &len, dataFile)) != -1) {
		// the first token is the number of integers to be sorted
		token = strtok_r(currLine, " ", &saveptr);
		// convert it into integer
		length = atoi(token);
		// create an array with size of length
		int array[length];
		// store all numbers into array
		for (int i = 0; i < length; i++) {
			token = strtok_r(NULL, " ", &saveptr);
			array[i] = atoi(token);
		} 

		mergeSort(array, 0, length - 1);
		for (int i = 0; i < length; i++) {
			printf("%d ", array[i]);
		}
		printf("\n");
	}

	return 0;
}









































