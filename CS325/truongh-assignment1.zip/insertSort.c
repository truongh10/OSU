#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>


void insertSort(int array[], int size) {
	for (int i = 1; i < size; i++) {
		int j = i;

		while(j >= 0 && array[j - 1] > array[j]) {
			int temp = array[j - 1];
			array[j - 1] = array[j];
			array[j] = temp;
			j--;
		}
	}
	for (int i = 0; i < size; i++) {
		printf("%d ", array[i]);
	}
	printf("\n");
}


int main() {
	char *currLine = NULL;
	char* saveptr, *token;	// for reading data.txt file
	int length = 0;	// stores the size of array
	size_t len = 0;
	ssize_t nread;

	// open data.txt file
	FILE *dataFile = fopen("data.txt", "r");
	//read the file line by line
	while ((nread = getline(&currLine, &len, dataFile)) != -1) {
		// the first token is the number of integers to be sorted
		token = strtok_r(currLine, " ", &saveptr);
		// convert it into integer
		length = atoi(token);
		// create an array with size of length
		int array[length];
		// store all numbers into array
		for (int i = 0; i < length; i++) {
			token = strtok_r(NULL, " ", &saveptr);
			array[i] = atoi(token);
		} 

		int size = sizeof(array)/sizeof(array[0]);		

		insertSort(array, size);
	}
		
}





























