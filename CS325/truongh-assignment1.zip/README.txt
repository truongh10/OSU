1. To compile insertSort.c:
	gcc -std=gnu -o insertSort insertSort.c
	to run: ./insertSort
2. To compile mergesort.c:
	gcc -std=gnu -o mergeSort mergesort.c
	to run: ./mergeSort
1. To compile insertTime.c:
	gcc -std=gnu -o insertTime insertTime.c
	to run: ./insertSort
1. To compile mergeTime.c:
	gcc -std=gnu -o mergeTime mergeTime.c
	to run: ./mergeTime
