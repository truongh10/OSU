To compile:	gcc --std=gnu99 -o movies_by_year main.c


	* Of all the files with the extension csv and prefix movie_
		* the largest file is movies_sample1.csv
		* The smallest file is movies_sample_2.csv
