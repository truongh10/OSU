#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <string.h>
#include "app.c"

int main() {
//   dirCreate();
//   smallestFile();
//   largestFile();
//   searchFile("moviesss.csv");
//   searchFile("movie_sample_1.csv");
//   fileCreate("movie_sample_1.csv");
   processChoice();
   return 0;
}
