#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <time.h>

/*
 * Struct for movie information
 */
struct movie {
   char* title;
   int year;
   char* languages;
   double rating;
   struct movie* next;
};

/*
 * Parse the current line which is space delimited and created
 * a movie struct with the data in this line
 */
struct movie *createMovie(char *currLine) {
   struct movie *currMovie = malloc(sizeof(struct movie));
   char * saveptr;

   // The first token is title
   char *token = strtok_r(currLine, ",", &saveptr);
   currMovie->title = calloc(strlen(token) + 1, sizeof(char));
   strcpy(currMovie->title, token);

   // The second token is year
   token = strtok_r(NULL, ",", &saveptr);
   currMovie->year = atoi(token); // Converting string into int year

   // The next token is languages
   token = strtok_r(NULL, ",", &saveptr);
   currMovie->languages = calloc(strlen(token) + 1, sizeof(char));
   strcpy(currMovie->languages, token);
   
   // The last token is the rating
   token = strtok_r(NULL, "\n", &saveptr);
   char *ptr;
   currMovie->rating = strtod(token, &ptr);
   
   // Set the next node to NULL in the newly created movie entry
   currMovie->next = NULL;

   return currMovie;
}

/*
 * Return a linked List of movies by parsing data from each line
 * of specific file
 */
struct movie *processFile(char* filePath) {

   // Open the specified file for reading only
   FILE *movieFile = fopen(filePath, "r");

   char * currLine = NULL;
   size_t len = 0;
   ssize_t nread;
   char *token;
   // The head of the linked list
   struct movie *head = NULL;
   // The tail of the linked list
   struct movie *tail = NULL;

   // Read the file line by line
   while ((nread = getline(&currLine, &len, movieFile)) != -1) {
   // Get a new movie node corresponding to the current line
   struct movie * newNode = createMovie(currLine);
   // Is this the first node in the linked list
      if (head == NULL) {
         // This is the first node in the linked list
         // Set the head and the tail to this node
	 head = newNode;
         tail = newNode;
      }
      else {
	 tail->next = newNode;
         tail = newNode;
      }
   }
   free(currLine);
   fclose(movieFile);
   return head;
}

/*
 * This function look for the smallest file with
 * the extension csv in current directory
 * whose name starts with prefix movie_ and return that file
 */
struct dirent *smallestFile() {
   char targetFilePrefix[32] = "movies_"; // prefix we're looking for
   DIR* dirToCheck; // Holds the directoy we're starting in
   struct dirent *fileInDir; // Holds the current subdir of the starting dir
   struct dirent *tempFile, *minFile;
   struct stat dirAttributes, tmpDirAttributes; // Holds information we've gained about subdir

   dirToCheck = opendir("."); // Open up the directory this program was run in
        
   if (dirToCheck > 0) {  // Make sure the current directory could be open
      while ((fileInDir = readdir(dirToCheck)) != NULL) { // check each entry in dir
         if(strstr(fileInDir->d_name, targetFilePrefix) != NULL && strstr(fileInDir->d_name, ".csv") != NULL) { // If entry has prefix
	    stat(fileInDir->d_name, &dirAttributes);
	    off_t i = dirAttributes.st_size;
	    tempFile = fileInDir; // assign fileInDir ti tempFile
	    while ((tempFile = readdir(dirToCheck)) != NULL) {
	       if(strstr(tempFile->d_name, targetFilePrefix) != NULL && strstr(tempFile->d_name, ".csv") != NULL) {
		  stat(tempFile->d_name, &tmpDirAttributes);
		  off_t j = tmpDirAttributes.st_size;
		  if (j >= i) {
		     minFile = fileInDir;
		  }
		  else if (j < i) {
		     minFile = tempFile;
		  }
	       }
	    }
         }
      }
      printf("\nNow processing the chosen file named %s\n", minFile->d_name);
      return minFile;
      closedir(dirToCheck); // close the directory we opened
   }
}


/*
 * This function look for the smallest file with
 * the extension csv in current directory
 * whose name starts with prefix movie_ and return that file
 */
struct dirent *largestFile() {
   char targetFilePrefix[32] = "movies_"; // prefix we're looking for
   DIR* dirToCheck; // Holds the directoy we're starting in
   struct dirent *fileInDir; // Holds the current subdir of the starting dir
   struct dirent *tempFile, *maxFile;
   struct stat dirAttributes, tmpDirAttributes; // Holds information we've gained about subdir
   char* fName;
   dirToCheck = opendir("."); // Open up the directory this program was run in
        
   if (dirToCheck > 0) {  // Make sure the current directory could be open
      while ((fileInDir = readdir(dirToCheck)) != NULL) { // check each entry in dir
         if(strstr(fileInDir->d_name, targetFilePrefix) != NULL && strstr(fileInDir->d_name, ".csv") != NULL) { // If entry has prefix
	    stat(fileInDir->d_name, &dirAttributes);
	    off_t i = dirAttributes.st_size; // assign the size of fileInDir to i
	    tempFile = fileInDir; // assign fileInDir to tempFile
	    while ((tempFile = readdir(dirToCheck)) != NULL) { // check each entry in dir
	       if(strstr(tempFile->d_name, targetFilePrefix) != NULL && strstr(tempFile->d_name, ".csv") != NULL) { // if entry has subtrings movie_ and .csv
		  stat(tempFile->d_name, &tmpDirAttributes);
		  off_t j = tmpDirAttributes.st_size;
		  if (j >= i) { // is size of tempFile greater than size of fileInDir
		     maxFile = tempFile; // assign tempFile to maxFile, max file is the largest file
		  }
		  else if (j < i) { // is size of tempFile less than size of fileInDir?
		     maxFile = fileInDir; // assign fileInDir to maxFile
		  }
	       }
	    }
         }
      }
      printf("\nNow processing the chosen file named %s\n", maxFile->d_name);
      return maxFile;
   }
   closedir(dirToCheck); // close the directory we opened
}


/*
 * This function checks if the input file exists on the current directory.
 * Print error message if not found.
 */
struct dirent *searchFile(char *file) {
   DIR* dirToCheck; // Holds the directory we're starting in
   struct dirent *fileInDir; // Hold the current subdir of the starting file
   int flag = 0; // 0 indicates file does not exist, 1 indicates file exists
//   struct stat dirAttributes; // Holds information we've gained about subdir

   dirToCheck = opendir("."); // Open up the directory this program was run in
   if (dirToCheck > 0) { // Make sure the current directory could be open
      while ((fileInDir = readdir(dirToCheck)) != NULL) { // check each entry in dir
	 if (strcmp(fileInDir->d_name, file) == 0) { // does the input file name match the name of current file
	    printf("File %s exists in current directory!\n", fileInDir->d_name);
            flag = 1; // file exists
            return fileInDir;
         }
      }
      if (flag == 0) { // if file not found
         printf("File %s does not exist!\n", file);
         return fileInDir = NULL;
      }
   }   
   closedir(dirToCheck); // close directory we've open
}



/*
 * This function concatenate strings
 */
char* concat(char* s1, char s2[10]) {
   char *s = malloc(strlen(s1) + strlen(s2) + 1); // adding 1 for null terminator
   strcpy(s, s1);
   strcat(s, s2);
   return s;
}

/*
 * This function creates a directory named truongh.movies.random, where random
 * is a number between 0 to 99999.
 * Permission: rwxr-x--- meaning onwer has read, write, execute permissions,
 *             group has read and execute permissions to the directory (0750)
 */
char *dirCreate () {
   int check;	// Holds return value of mkdir()
   srandom(time(NULL));
   char snum[10]; // stores random number as a string
   
   // Generate random number for directory
   long int num = random() % 100000;
   sprintf(snum, "%d", num);	//make the number into string

   // Concatenating two strings into dirName
   char *dirName = concat("truongh.movies.", snum);
   
   // Creating directory, mkdir() return 0 if directory is create successfully
   // or -1 if failed
   check = mkdir(dirName, 0750);
   if (check == 0) {
      printf("Created directory with name %s\n", dirName);
      return dirName;
   }
   else {
      printf("Unable to create directory!\n");
      exit(1);
   }
}

/*
 * free movie
 */
void movieFree(struct movie* movie) {
   struct movie* tmp = NULL;
   while (movie != NULL) {
      tmp = movie->next;
      free(movie->title);
      free(movie->languages);
      movie = tmp;
   }
   free(movie);
}

/*
 * This function parse data from chosen file and create movie files in
 * new directory
 */
void fileCreate(char* file) {
   DIR* dirToCheck; // Holds the directory we're starting in
   char *dirName = dirCreate(); // Holds the name of new directory

   struct movie *movie = processFile(file); // creating list and parsing data of chosen file into list
   FILE* fptr;
   char snum[10]; // Holds year of movie as string

   dirToCheck = opendir(dirName); // Open up new directory
   if (dirToCheck > 0) { // make sure the diretory could be open
      for (int i = 1000; i <= 9999; i++) { // For each each from 1000 to 9999
	 struct movie* tmp = movie;
         while (tmp != NULL) { // Check each movie node
	    if (tmp->year == i) { // if movie found in that year
	       sprintf(snum, "%d", i); // making the year into string
	       char *fileN = concat(dirName, "/");
	       char *fileN1 = concat(snum, ".txt");
               char* fileName = concat(fileN, fileN1); // concatenates two string to make fileName
	       fptr = fopen(fileName, "a"); // create/open file for append mode
	       if (fptr == NULL) { // faied to open
		  printf("Unable to create file %s.\n", fileName);
		  exit(1);
	       }
	       fprintf(fptr, "%s\n", tmp->title); // write movie name into file
	       fclose(fptr); // close file
	    }
            tmp = tmp->next; // move to next movie node
	    
	 }
      }
   }
   closedir(dirToCheck); // close the directory we opened
   movieFree(movie);
}

/*
 * This prints menu to screen
 */
void printMenu() {
   printf("Which file you want to process?\n");
   printf("Enter 1 to pick the largest file\n");
   printf("Enter 2 to pick the smallest file\n");
   printf("Enter 3 to specify with name of the file\n");
}


void processChoice() {
   int flag = 1;
   int choice; // Holds the input of user
   int opt; // holds input of user
   do {
      int p = 1;
      printf("1. Select file to process\n");
      printf("2. Exit the program\n");
      printf("\nEnter a choice 1 or 2: ");
      scanf("%d", &choice); // gets user input
      if (choice == 1) { // select file to process
         while(p == 1) {
	    char* fileName;
            struct dirent* minFile, *file, *biggestFile;
	    printMenu(); // print menu
	    printf("Enter a choice from 1 to 3: ");
	    scanf("%d", &opt); //gets user input
	 
	    switch (opt) {
	       case 1: // pick the largest file
                  biggestFile = largestFile();
	          fileCreate(biggestFile->d_name);
		  p = 0;
	          break;
	       case 2:
	          minFile = smallestFile();
	          fileCreate(minFile->d_name);
		  p = 0;
	          break;
	       case 3:
	          printf("Enter the complete file name: ");
	          scanf("%s", fileName);
   	          file = searchFile(fileName);
   	          if (file == NULL) {
		     p = 1;
		     break; 
		  }
		  else if (file != NULL) {
		     fileCreate(file->d_name);
		     p = 0;
		  }
                  break;
	       default:
		  printf("Enter an incorrect choice. Try again!\n");
		  p = 1;
            }
         }
      }
      else if (choice == 2) { // exit the program
         flag = 0;
         exit(0);
      }
   } while (flag == 1);
}



































