#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/socket.h>
#include <netinet/in.h>


/*
 * dec_server code
 * 1. Create a socket
 * 2. Set up address struct for the server socket
 * 3. Bind socket to server address struct
 * 4. Start listening for connections. Allow up to 5 connections to queue up
 * 5. Accept connections and fork a process for each one
 * 6. child Process checks to make sure it's communicating with dec_client, then receives
 * ciphertext and key and sends back the plaintext to dec_client
 */


#define bufferSize 80000

// Error function used for reporting issues
void error(const char *msg) {
  perror(msg);
  exit(1);
} 

// Set up the address struct for the server socket
void setupAddressStruct(struct sockaddr_in* address, int portNumber){
 
  // Clear out the address struct
  memset((char*) address, '\0', sizeof(*address)); 

  // The address should be network capable
  address->sin_family = AF_INET;
  // Store the port number
  address->sin_port = htons(portNumber);
  // Allow a client at any address to connect to this server
  address->sin_addr.s_addr = INADDR_ANY;
}


// This fuction receives ciphertext and key from dec_client
// and decrypts data, then sends plaintext back to dec_client
void decrypt(int connectionSocket, char* ciphertext, char* key, char* plaintext, char*accept, char* reject) {
	int charsRead, charsWritten;
	char processName[20];
	memset(processName, '\0', sizeof(processName));

	// Check to see if it's from enc_client process
	// Accept if it is, else reject
	charsRead = recv(connectionSocket, processName, sizeof(processName), 0);
	if (charsRead < 0)
		error("ERROR reading from socket");
	if (strstr(processName, "dec_client") != NULL) {
		charsWritten = send(connectionSocket, accept, sizeof(accept), 0);
		if (charsWritten < 0)
			error("ERROR writing to socket");
	}
	else {
		charsWritten = send(connectionSocket, reject, sizeof(reject), 0);
		if (charsWritten < 0)
			error("ERROR writing to socket");
		fprintf(stderr, "Connection from expected program\n");
		exit(1);
	}

	// read size of ciphertext
	int size = 0;
	charsRead = recv(connectionSocket, &size, sizeof(size), 0);
	if (charsRead < 0)
		error("ERROR reading from socket");

	// Read ciphertext from socket
	memset(ciphertext, '\0', sizeof(ciphertext));
	charsRead = recv(connectionSocket, ciphertext, size, 0);
	if (charsRead < 0)
		error("ERROR reading from socket");

	// Read key fron socket
	memset(key, '\0', sizeof(key));
	charsRead = recv(connectionSocket, key , size, 0);
	if (charsRead < 0)
		error("ERROR reading from socket");


	// Decrypt data
	memset(plaintext, '\0', sizeof(plaintext));
	for (int i = 0; i < strlen(ciphertext); i++) {
		int num1, num2;
		int sum = 0;
		char characters[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZ ";
		for (int j = 0; j < 27; j++) {
			if (ciphertext[i] == characters[j])
				num1 = j;
			if (key[i] == characters[j])
				num2 = j;
		}
		sum = num1 - num2;
		if(sum < 0)
			sum += 27;
		plaintext[i] = characters[sum];
	}
	printf("%s\n", plaintext);	

	// Send decrypted text back to dec_client
	charsWritten = send(connectionSocket, plaintext, size, 0);
	if (charsWritten < 0)
		error("ERROR writing to socket");
	close(connectionSocket);
}



int main(int argc, char* argv[]) {
	int connectionSocket, charsRead, charsWritten;
	int status;
	int processNum = 0;
	pid_t pid;
	char plaintext[bufferSize];
	char key[bufferSize];
	char ciphertext[bufferSize];
	char acceptConnection[] = "accept";
	char rejectConnection[] = "reject";
	struct sockaddr_in serverAddress, clientAddress;
	socklen_t sizeOfClientInfo = sizeof(clientAddress);

	// Check usage and args
	if (argc < 2) {
		fprintf(stderr, "USAGE: %s listening_port\n", argv[0]);
		exit(0);
	}	

	// Create the socket that will listen for connection
	int listenSocket = socket(AF_INET, SOCK_STREAM, 0);
	if (listenSocket < 0) {
		error("ERROR opening sokcet");
	}

	// Set up the address struct for server socket
	setupAddressStruct(&serverAddress, atoi(argv[1]));

	// Associate the socket to the port
	if (bind(listenSocket, (struct sockaddr *)&serverAddress, sizeof(serverAddress)) < 0) {
		close(listenSocket);
		error("ERROR on binding");
	}

	// Start listening for connections. Allow up to 5 connections
	listen(listenSocket, 5);

	while (1) {
		// Accept the connection request which creates a connect
		connectionSocket = accept(listenSocket, (struct sockaddr*)&clientAddress, &sizeOfClientInfo);
		if (connectionSocket < 0) {
			close(listenSocket);
			error("ERROR on accept");
		}
		if (processNum < 5) {
		// fork a process
			pid = fork();
			switch(pid) {
				case -1:
					error("ERROR on fork()!");
					break;
				// CHild process
				case 0:
					close(listenSocket);
					decrypt(connectionSocket, ciphertext, key, plaintext, acceptConnection, rejectConnection);
					exit(0);
					break;
				// parent process
				default:
					processNum++;
					break;
			}
		}
		else fprintf(stderr,"Number of active processes is 5. Wait for completion of one process\n");
		for (int i = 0; i < 5; i++) {
			if(waitpid(-1, &status, WNOHANG) == -1)
				fprintf(stderr,"ERROR on waitpid()\n");
			if (WIFEXITED(status))
				processNum--;
		}
	}

	close(listenSocket);	



	return 0;
}







