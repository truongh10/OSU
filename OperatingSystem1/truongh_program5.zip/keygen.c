#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>

/******************************************************
 * This program creates a key file of specified length.
 * The characters in the file generated will be any of
 * the 27 allowed characters.
 *****************************************************/
int main(int argc, char* argv[]) {
   // in case length of case is not provided
   if (argc < 2) {
      fprintf(stderr, "Length of key is not provided!\n");
      fprintf(stderr, "Please provide keylength followed by keygen: keygen keylength\n");
      exit(1);
   }

   long keyLength = atoi(argv[1]); // holds the length of key specified by user
   char key[atoi(argv[1])]; // generated key;
   memset(key, '\0', sizeof(key));


   // handle negative keylength
   if (keyLength <= 0) {
      fprintf(stderr, "Invalid keylength! keylength must be greater than 0!\n");
      exit(1);
   }

   srand(time(NULL));

   // store each random char into char array of key
   long i = 0;
   for (i = 0; i < keyLength; i++) {
      char characters[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZ "; //characters that will be generated
      int randChar = rand() % 27; // randomly generate number from 0 to 26 with 0 being A and 1 being B...
      key[i] = characters[randChar]; // store char of characters at ranChar into current position of key

   }
   key[keyLength] = '\0';
   printf("%s\n", key);
/*
   char cipher[10];
   memset(cipher, '\0', sizeof(cipher));
   char* str = "HELLO";
   for (int i = 0; i < strlen(str); i++) {
      int num, num2;
      int sum = 0;
      char s[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZ ";
         for (int j = 0; j < 27; j++) {
            if (str[i] == s[j])
               num = j;
            if (key[i] == s[j])
	       num2 = j;
         }
	 sum = (num + num2) % 27;
	 cipher[i] = s[sum];
   }
   printf("cipher: %s\n", cipher);
*/
   return 0;
}





















