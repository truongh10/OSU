#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>	// ssize_t
#include <sys/socket.h>	// sned(), recv()
#include <netdb.h>	// gethostbyname()

/*
 * dec_client code
 * 1. Create a socket and connect to the server specified in command arguments
 * 2. Open ciphertext and mykey files and process data in files
 * 3. send data to dec_server
 * 4. print the dara received from server
 */

#define bufferSize 80000


// Error function used for reporting issue
void error(const char *msg) {
	perror(msg);
	exit(0);
}

// Set up the address struct
void setupAddressStruct(struct sockaddr_in * address, int portNumber, char *hostname) {
	// Clear out the address struct
	memset((char*) address, '\0', sizeof(*address));

	// The address should be network capable
	address->sin_family = AF_INET;
	// Store the port number
	address->sin_port = htons(portNumber);

	// Get the DNS entry for this host name
	struct hostent *hostInfo = gethostbyname(hostname);
	if (hostInfo == NULL) {
		fprintf(stderr, "enc_lient: ERROR, no such host!\n");
		exit(0);
	}
	// Copy the first IP address from the DNS entry to sin_addr.s_addr
	memcpy((char*) &address->sin_addr.s_addr, hostInfo->h_addr_list[0], hostInfo->h_length);

}


int main(int argc, char *argv[]) {
	int socketFD, portNumber, charsWritten, charsRead;
	struct sockaddr_in serverAddress;
	char buffer[bufferSize], key[bufferSize];
	FILE *ciphertext, *keyFile;

	if (argc < 4) {
		fprintf(stderr, "USAGE: %s ciphertext key port\n", argv[0]);
		exit(0);
	}

	// Create Socket
	socketFD = socket(AF_INET, SOCK_STREAM, 0);
	if (socketFD < 0)
		error("dec_client: ERROR opening sokcet");


	// Set up the server address struct
	setupAddressStruct(&serverAddress, atoi(argv[3]), "localhost");

	// Connect to the server
	if (connect(socketFD, (struct sockaddr*) &serverAddress, sizeof(serverAddress)) < 0) {
		close(socketFD);
		error("dec_client: ERROR connecrting");

	}

	// Send process name to enc_server to inform it's coming from enc_client
	// enc_server only accepts connection from enc_client
	// enc_server is not allowed to connect to dec_server
	char *processName = "dec_client";
	if (send(socketFD, processName, strlen(processName), 0) < 0) {
		fprintf(stderr, "dec_client: ERROR writing to socket\n");
		close(socketFD);
		exit(2);
	}

	// Receive message from server
	char msg[100];
	if (recv(socketFD, msg, sizeof(msg), 0) < 0) {
		fprintf(stderr, "dec_client: ERROR reading from socket\n");
		close(socketFD);
		exit(1);
	}
	// Check if server reject or accept connection
	// if server rejects connection, then exit
	if (strstr(msg, "reject") != NULL) {
		fprintf(stderr, "dec_client: ERROR dec_server denied connection on port %d\n", atoi(argv[3]));
		close(socketFD);
		exit(2);
	}

	// Open ciphertext file for reading
	ciphertext = fopen(argv[1], "r");
	if (ciphertext == NULL) {
		close(socketFD);
		fprintf(stderr, "dec_client: Could not open %s file\n!", argv[1]);
		exit(1);
	}
	// clear buffer
	memset(buffer, '\0', sizeof(buffer));
	// Read text until new line is encountered
	fscanf(ciphertext, "%[^\n]", buffer);


	// Check for invalid chars
	for (int i = 0; i < strlen(buffer); i++) {
		char str[] = "ABCDFEGHIJKLMNOPQRSTUVWXYZ ";
		int num = 0;
		for (int j = 0; j < 27; j++) {
			if (buffer[i] != str[j])
				num++;
		}


		if (num > 26) {
			close(socketFD);
			fprintf(stderr, "dec_client: Invalid character found in the text!\n");
			exit(1);
		}
		
	}
	// Close ciphertext file
	fclose(ciphertext);


	// Open key file for reading
	keyFile = fopen(argv[2], "r");
	if (keyFile == NULL) {
		close(socketFD);
		fprintf(stderr, "dec_client: Could not open %s file\n!", argv[1]);
		exit(1);
	}
	// clear key
	memset(key, '\0', sizeof(key));
	// Read text until next line is encountered
	fscanf(keyFile, "%[^\n]", key);


	// Check for invalid chars
	for (int i = 0; i < strlen(key); i++) {
		char str[] = "ABCDFEGHIJKLMNOPQRSTUVWXYZ ";
		int num = 0;
		for (int j = 0; j < 27; j++) {
			if (key[i] != str[j])
				num++;
		}
		if (num > 26) {
			close(socketFD);
			fprintf(stderr, "dec_client: Invalid character found in key!\n");
			exit(1);
		}
	}

	// Close keyFile
	fclose(keyFile);

	// Check to see if length of key is less than length of buffer
	// exit program if it is
	if (strlen(key) < strlen(buffer)) {
		close(socketFD);
		fprintf(stderr, "Error: key '%s' is too short\n", argv[2]);
		exit(1);
	}

	// Send buffer to server
	// write to the server
	int ciphertextSize = strlen(buffer);
	charsWritten = send(socketFD, &ciphertextSize, sizeof(ciphertextSize), 0);
	if (charsWritten < 0) {
		close(socketFD);
		fprintf(stderr, "dec_client: ERROR writing to socket\n");
		exit(1);
	}
	charsWritten = send(socketFD, buffer, strlen(buffer), 0);
	if (charsWritten < 0) {
		close(socketFD);
		fprintf(stderr, "dec_client: ERROR writing to socket\n");
		exit(1);
	}
	if (charsWritten < strlen(buffer)) 
		printf("dec_client: WARNING: Not all data written to socket\n");

	// Send key to server
	// Write to the server
	charsWritten = send(socketFD, key, strlen(key), 0);
	if (charsWritten < 0) {
		close(socketFD);
		fprintf(stderr, "dec_client: ERROR writing to socket\n");
		exit(1);
	}
	if (charsWritten < strlen(buffer)) 
		printf("dec_client: WARNING: Not all data written to socket\n");

	// Clear buffer
	memset(buffer, '\0', sizeof(buffer));
	// Read data from socket
	charsRead = recv(socketFD, buffer, ciphertextSize, 0);
	if (charsRead < 0) {
		fprintf(stderr, "dec_client: ERROR reading from sokcet\n");
	}
	printf("%s\n", buffer);

	// Close sokcet
	close(socketFD);

	return 0;
}






































































