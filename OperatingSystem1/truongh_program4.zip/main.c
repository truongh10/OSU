#include <stdlib.h>
#include <stdio.h>
#include "app.c"

int main(int argc, char *argv) {
   test();
   return 0;
}
