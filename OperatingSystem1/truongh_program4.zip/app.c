#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <pthread.h>
#include <unistd.h>
#include <stdbool.h>

//size of an input line
#define Size 1000

// Program will never have more than 49 lines
#define Line 50

// Special marker used to define to indicate end of the producer data
#define STOP_MARKER "STOP\n"

// Buffer 1, shared resource between input thread and line separator thread
char buffer_1[Size * Line];
// Initialize the muxtex for buffer 1
pthread_mutex_t mutex_1= PTHREAD_MUTEX_INITIALIZER;
// Initialzier condition variable foe buffer 1
pthread_cond_t full_1 = PTHREAD_COND_INITIALIZER;
int count_1 = 0;


// Buffer 2, shared resource between line separator thread and plus sign thread
char buffer_2[Size * Line];
// Initialize the muxtex for buffer 1
pthread_mutex_t mutex_2= PTHREAD_MUTEX_INITIALIZER;
// Initialzier condition variable foe buffer 1
pthread_cond_t full_2 = PTHREAD_COND_INITIALIZER;
int count_2 = 0;


// Buffer 3, shared resource between plus sign thread and output thread
char buffer_3[Size * Line];
// Initialize the muxtex for buffer 3
pthread_mutex_t mutex_3 = PTHREAD_MUTEX_INITIALIZER;
// Initialzier condition variable foe buffer 1
pthread_cond_t full_3 = PTHREAD_COND_INITIALIZER;
int count_3 = 0;


/****************************************
 * Get input from user.
 ****************************************/
char *getInput() {
   char input[Size];
   printf(": ");
   fflush(stdout);
   fflush(stdin);
   fgets(input, Size, stdin);

//   printf("Input: %s\n", input);
//   fflush(stdout);
 
   return input;
}

/****************************************
 * put data in buffer_1
 ***************************************/
void putBuff1(char *item) {
   // Lock the mutex before putting the item in the buffer
   pthread_mutex_lock(&mutex_1);
   // put the item in the buffer
   for (int i = 0; i <= strlen(item); i++)
      buffer_1[i] = item[i];
//   buffer_1[strlen(buffer_1)] = END_MARKER;

//   printf("buffer_1: %s\n", buffer_1);
//   fflush(stdout);
   
   count_1++;
   //signal to the comsumer that the buffer is no loger empty
   pthread_cond_signal(&full_1);
   //Unlock the mutex
   pthread_mutex_unlock(&mutex_1);
}


/*******************************************
 * Function that the input thread will run.
 * Get input from user.
 * put item in the buffer shared with
 * line-separator thread.
 ******************************************/
void *get_input(void *args) {
 
   for (int i = 0; i < Line; i ++) {
      // Get user input
      char *item = getInput();

//      printf("Item: %s\n", item);
//      fflush(stdout);
      if (strcmp(item, "STOP\n") == 0) {
         putBuff1(item);
         break;
      }
      putBuff1(item);
   }
   return NULL;
}

/****************************************
 * Get the next item from the buffer 1 
 ***************************************/
char * getBuff1() {
   // lock the mutex before checking if buffer has data
   pthread_mutex_lock(&mutex_1);
   while (count_1 == 0)
      // buffer is empty. wait for producer to signal that buffer has data
      pthread_cond_wait(&full_1, &mutex_1);
   char item[Size];
   strcpy(item, buffer_1);

//   printf("In getBuff1--- item: %s\n", item);
//   fflush(stdout);

   count_1--;
   // unlock the mutex
   pthread_mutex_unlock(&mutex_1);
   return item;
}

/************************************
 * put an item in buffer 2
 ***********************************/
void putBuff2(char *item) {
   pthread_mutex_lock(&mutex_2);
   strcpy(buffer_2, item);

//   printf("In putBuff2--- buffer_2: %s\n", buffer_2);
//   fflush(stdout);

   count_2++;
   pthread_cond_signal(&full_2);
   pthread_mutex_unlock(&mutex_2);
}


/*
Replace line separator by space 
*/
char *replaceNewline(char* item) {
   for (int i =0; i <= strlen(item); i++) {
      if(item[i] == '\n')
         item[i] = ' ';
   }
   return item;
}


/****************************************
 * Function that line separator thread will
 * run. Consume data from the buffer shared 
 * with input thread.
 * Replace new separator by space.
 * Produce data in buffer shared with plus
 * sign thread.
 ***************************************/
void *lineSeparator(void *args) {
   char *item;
   int i = 0;
//while (strstr(item, "STOP") != NULL) { 

   for (i = 0; i < Line; i++) {
      item = getBuff1();
      

//   printf("In lineSeparator--- item: %s\n", item);
//   fflush(stdout);
      
      if (strcmp(item, "STOP\n") == 0) {
         putBuff2(item);
         break;
      }    

      replaceNewline(item);
      putBuff2(item);
      
   }
   return NULL;
}


/*
 * Get the data from buffer 2
 */
char *getBuff2() {
   pthread_mutex_lock(&mutex_2);
   while (count_2 == 0)
      pthread_cond_wait(&full_2, &mutex_2);
   char item[Size];
   strcpy(item, buffer_2);

//   printf("In getBuff2()--- item: %s\n", item);
//   fflush(stdout);

   count_2--;
   pthread_mutex_unlock(&mutex_2);
   return item;
}


/*
 Put data in buffer 3
 */
void putBuff3(char * item) {
   pthread_mutex_lock(&mutex_3);

//   printf("In putBuff3()++++ item: %s\n", item);
//   fflush(stdout);
   strcpy(buffer_3, item);
   count_3++;
//   printf("In putBuff3()++++ buffer_3: %s\n", buffer_3);
//   fflush(stdout);

   pthread_cond_signal(&full_3);
   pthread_mutex_unlock(&mutex_3);
}


/*
 Replace plus sign
*/
char *replacePlusSign(char *item) {
   char buff2[strlen(item) - 1];
   while (strstr(item, "++") != NULL) {
//      printf("in WHILE___ item: %s\n", item);
//      fflush(stdout);
      memset(buff2, '\0', sizeof(buff2));
      int i = 0;
      for(int i = 0; i < strlen(item); i++) {
         if (item[i] == '+' && item[i+1] == '+') {
            strncpy(buff2, item, i);
            
            strcat(buff2, "^");
//           buff2[strlen(buff2)] = '^';
//            printf("strncpy+++++ buff2: %s\n", buff2);
//            fflush(stdout);
            int j = i + 2;
            int s = strlen(buff2);
            while (j < strlen(item) - 1) {
//               if(item[j] != '\0')
                  buff2[s++] = item[j];
               j++;
            }
            s--;
            for (int j = 0; j <= s; j++) {
               if(buff2[j] == '\n')
                  buff2[j] = ' ';
            }
//            printf("new buff2______ buff2: %s\n", buff2);
//            fflush(stdout);

//            buff2[strlen(buff2)] = '\0';
//            s--;
//            replaceNewline(buff2);
            
//            printf("after calling... buff2: %s\n", buff2);
//            fflush(stdout);

            memset(item, '\0', sizeof(item));
            strcat(item, buff2);
//            for (int k = 0; k <= s; k++) {
//               if(buff2[k] != '\0')
//                  item[k] = buff2[k];
//            }
//            memset(item1, '\0', sizeof(item1));
//            item1 = item;
            break;
         }
      }
   }
   return item;
}

/***************************************
 * function that plus sign thread will run.
 * Consume data from buffer shared with line
 * separator threa.
 * Replace ever pair of plus signs with a caret.
 * Produce data in the buffer shared with 
 * ouput thread.
 ***************************************/
void *plusSign(void *args) {
   char *item;
   for (int i = 0; i < Line; i++) {
      item = getBuff2();
//      printf("In plusSign()!!!!!!! item: %s\n", item);
//     fflush(stdout);
      if (strstr(item, "STOP\n") != NULL) {
         putBuff3(item);
         break;
      }
   
      replacePlusSign(item);
      putBuff3(item);
   }
   return NULL;
}

/*
 Get the data from buffer 3
*/
char *getBuff3() {
   pthread_mutex_lock(&mutex_3);
   while (count_3 == 0) 
      pthread_cond_wait(&full_3, &mutex_3);
   char item[Size];
//   memset(item, '\0', sizeof(item));
   strcpy(item, buffer_3);
   count_3--;
//   printf("In getBuff3()****** item: %s\n", item);
//   fflush(stdout);
   pthread_mutex_unlock(&mutex_3);

   return item;
}


/*
 This function writes the processed data to standard output
 as lines of exactly 80 chars
*/
char *outputLines(char *item) {
   char buffer[Size * Line];
   memset(buffer, '\0', sizeof(buffer));

   size_t size = strlen(item);
   while (size >= 80) {
      printf("Output: ");
      fflush(stdout);
      write(1, item, 80);
      write(1, "\n", 2);
      int s = 79;
      for (int i = 0; i < strlen(item); i++) {
         if (item[s++] != '\0') {
            buffer[i] = item[s];
         }
         else
            break;
      }
      memset(item, '\0', sizeof(item));

      strcpy(item, buffer_3);

      size = size - 80;
   }
   return item;
}



void *output(void *agrs) {
   char *item;
   char buffer[Size * Line];
   memset(buffer, '\0', sizeof(buffer));
//while (strstr(item, "STOP") != NULL) {
   for (int i = 0; i < Line; i++) {
      item = getBuff3();
      strcat(buffer, item);
//         printf("\n Output: %s\n", item);
         if (strstr(item, "STOP\n") != NULL) {
            break;
         }
         else {  
            outputLines(buffer);
//            printf("buffer: %s\n", buffer);
         }
   }
//}
   return NULL;
}


void test() {
      memset(buffer_1, '\0', sizeof(buffer_1));
      memset(buffer_2, '\0', sizeof(buffer_2));
      memset(buffer_3, '\0', sizeof(buffer_3));
//   char* item = getInput();

   pthread_t input_t, lineSeparator_t, plusSign_t, output_t;

   pthread_create(&input_t, NULL, get_input, NULL);
   pthread_create(&lineSeparator_t, NULL, lineSeparator, NULL);
   pthread_create(&output_t, NULL, output, NULL);
   pthread_create(&plusSign_t, NULL, plusSign, NULL);
//   printf("created!!!\n");

   pthread_join(input_t, NULL);
   pthread_join(lineSeparator_t, NULL);
   pthread_join(output_t, NULL);
   pthread_join(plusSign_t, NULL);
   
//   printf("count_1 = %d\n", count_1);
//   printf("count_2 = %d\n", count_2);

}



























