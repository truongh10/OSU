#include "smallsh.c"
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>




int main() {
   struct commands* command = getCommand();
   free (command->inputFile);
   free(command->outputFile);
   free(command);
   return 0;
}
