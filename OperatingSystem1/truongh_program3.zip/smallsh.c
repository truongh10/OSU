#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <signal.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/wait.h>

#define MAX_ARG 512
#define MAX_COMMAND_LENGTH 2048

int beforeForeground = 0;
int fgOnlyMode = 0;
 
/******************************************
 * Struct for command information
 *****************************************/
struct commands {
   char* args[MAX_ARG];
   int processes[100];
   char* inputFile;
   char* outputFile;
   char* background;
   int argNum;
   int processNum;
   int isBackground;
};

/**********************************************
 * This function expands any instance of "$$"
 * in a command into process id of the smallsh
 * itself.
 **********************************************/
char * expand (char input[MAX_COMMAND_LENGTH]) {
   fflush(stdout);
   char newInput[MAX_COMMAND_LENGTH];
   while (strstr(input, "$$") != NULL) {
      memset(newInput, '\0', sizeof(newInput));
      char pid[10];
      sprintf(pid, "%d", getpid());
      for (int i = 0; i < strlen(input); i++) {
         if (input[i] == '$' && input[i+1] == '$') {
            strncpy(newInput, input, i);
            strcat(newInput, pid);
            int j = i + 2;
            int s = strlen(newInput);
            while (j < strlen(input)) {
               newInput[s++] = input[j];
               j++;
            }
            break;
         }
      }
      strcpy(input, newInput);
   }
   return input;
}

/************************************************
 * This function redirects input
 ***********************************************/
void redirectIn(char* inputFile) {
   if (inputFile != NULL) { 
      int fd = open(inputFile, O_RDONLY, 0744); // open file for read only
      if (fd == -1) { // if failed
      printf("Could not open %s\n!", inputFile);
      fflush(stdout);
      exit(1);
      }
      dup2(fd, 0); // redirect input
      close(fd); // close file
   }
}

/************************************************
 * This function redirects output
 ***********************************************/
void redirectOut(char* outputFile) {
   if (outputFile != NULL) {
      int fd1 = open(outputFile, O_CREAT | O_WRONLY | O_TRUNC, 0744); // creat/open file
      if (fd1 == -1) { // if failed
         printf("Could not open %s\n", outputFile);
         fflush(stdout);
         exit(1);
      }
      dup2(fd1, 1); // redirect output
      close(fd1); // close file
   }
}

/******************************************
 * This function prints out either the exit
 * status or the terminating signal of the
 * last foreground process
 *****************************************/
void statusCommand(int isBg, int beforeForeground, int childStatus) {
   if (beforeForeground == 0) // no foreground command is run yet
      printf("exit value 0\n"); // return exit status 0
   else if (beforeForeground == 1){
      if(isBg == 0) {
         if (WIFEXITED(childStatus)) // WIFEXITED returns true if process exits normally
            printf("exit value %d\n", WEXITSTATUS(childStatus));
         if (WIFSIGNALED(childStatus)) // WIFSIGNALED returns true if process exits abnornmally 
            printf("terminated by signal %d\n", WTERMSIG(childStatus));
      }
   }
   fflush(stdout);
}


/*********************************************
 * This function changes the working directory
 * of smallsh. If no arguments after cd, then
 * change to home directory. If path of directory
 * is provided, then change to that direcotry
 ********************************************/
void cdCommand (char* path) {
   char cwd[1024]; // store path to current dirrectory
   if (path == NULL) { // cd with no arguments
      chdir(getenv("HOME")); // change to home directory
//      getcwd(cwd, sizeof(cwd)); // get path to current directory
//      printf("PWD: %s\n", cwd);
//      fflush(stdout);
   }
   else if (path != NULL) {
      if(chdir(path) != 0) {
         printf("chdir() to %s failed!\n", path);
         fflush(stdout);
      }
   }
}

/****************************************
 * This function exits the shell.
 * Shell must kill all processes before
 * it terminates itself
 ***************************************/
void exitCommand(int processes[100], int processNum) { //it is safe to assume the max number of running processes is 100
   if (processNum > 0) { // are there multiple processes still running?
      for(int i = 0; i < processNum; i++) { // for each process pid stored in array
         kill(processes[i], SIGKILL); // kill process
      }
   } 
   exit(0); //exit
}



/***********************************************
 * This function processes built-in command
 **********************************************/
void builtIn(int isBg, char *command, char* argument, int processes[100], int processNum, int beforeForeground, int childStatus) {
   if (strcmp(command, "cd") == 0) { // is command cd?
      cdCommand(argument);  // process cd command
   }
   else if (strcmp(command, "exit") == 0) { // is command exit?
      exitCommand(processes, processNum); // process exit command
   }
   else if (strcmp(command, "status") == 0) { // is command status
      statusCommand(isBg, beforeForeground, childStatus); // process status command
   }
}






/**************************************************
 * This function execute non-built-in commands using
 * execvp. if command is in foreground mode, parent 
 * must wait for child to terminate. if command is 
 * in background mode, then parent does not have to
 * wait for child completion. Check for any terminated
 * child and print status
 *************************************************/
void nonBuiltIn( struct commands* command, struct sigaction SIGINT_action, struct sigaction SIGTSTP_action) {
   pid_t spawnpid = -5;
   int childStatus;
   spawnpid = fork(); // FORKKKKKKKK FOR MEEEEEE

   switch(spawnpid) {
      // fork() failed
      case -1:
         perror("fork() failed!\n");
         exit(1);
         break;
      // in child process
      case 0:
            // all chidren (bg/fg) must ignore SIGTSTP
            SIGTSTP_action.sa_handler = SIG_IGN;
            sigaction(SIGTSTP, &SIGTSTP_action, NULL);

            if(command->isBackground == 0 || fgOnlyMode == 1) { // foreground process
               // register SIG_DFL as the signal handler
               // SIG_DFL means the process terminate when recieved ^C
               SIGINT_action.sa_handler = SIG_DFL;
               // Install our signal handler
               sigaction(SIGINT, &SIGINT_action, NULL);
            } 
            // redirect to /dev/null in background if not specified by user
            if(command->isBackground == 1) {
               if(command->inputFile == NULL)
                  redirectIn("/dev/null");
               if(command->outputFile == NULL)
                  redirectOut("/dev/null");
            }

            // redirect if necessary
            if(command->inputFile != NULL)
               redirectIn(command->inputFile);
            if(command->outputFile != NULL)
               redirectOut(command->outputFile);

            execvp(command->args[0], command->args); // execute the command
            // execvp failed
            printf("%s cound not be executed!\n", command->args[0]);
            fflush(stdout);
            exit(1);
            break;
      // in parent process
      default:
         if (command->isBackground == 1 && fgOnlyMode == 0) { // this is background
            printf("background pid is %d\n", spawnpid);
            fflush(stdout);
            waitpid(spawnpid, &childStatus, WNOHANG); // allow parent to move on even child has not terminated
            command->processes[command->processNum] = spawnpid; // store child pid in array
            command->processNum++;
         }
         else { // is it foreground
            beforeForeground = 1;
            command->isBackground = 0;
            waitpid(spawnpid, &childStatus, 0); // wait until child process terminate
//            if (WIFEXITED(childStatus)) // WIFEXITED returns true if process exits normally
//               printf("exit value %d\n", WEXITSTATUS(childStatus));
            if (WIFSIGNALED(childStatus)) // WIFSIGNALED returns true if process exits abnornmally 
               printf("terminated by signal %d\n", WTERMSIG(childStatus));
         }
         break;
   }
   //check for child completion
   while ((spawnpid = waitpid(-1, &childStatus, WNOHANG)) > 0) { // for each child terminated
      for (int i = 0; i < command->processNum; i++) { // loop through array
         if (command->processes[i] == spawnpid) { // terminated child found
            for (int j = i; j < command->processNum; j++) { // for each element after terminated child
               command->processes[j] = command->processes[j+1]; // move it up by one position
            }
            break; // break out of for loop
         }
      }
      printf("background pid %d is done: ", spawnpid);
      fflush(stdout);
      if (WIFEXITED(childStatus)) // WIFEXITED returns true if process exits normally
         printf("exit value %d\n", WEXITSTATUS(childStatus));
      if (WIFSIGNALED(childStatus)) // WIFSIGNALED returns true if process exits abnornmally
         printf("terminated by signal %d\n", WTERMSIG(childStatus));
      // print status of terminated child
   }
}

/***********************************************
 * This function handles SIGTSTP. when parent 
 * receives SIGTSTP, shell enter foreground-only
 * mode. When user sends SIGTSTP again, shell 
 * returns back to nornal condition
 **********************************************/
void handle_SIGTSTP (int signo) {
   if (fgOnlyMode == 0) { // is it in normal condition?
      fgOnlyMode = 1; // set it to foreground-only mode
      fflush(stdout);
      char* message = "Entering foreground-only mode (& is now ignore)\n";
      write(1, message, 49);
      fflush(stdout);
      write(1, ": ", 2);
   }
   else { // it's in foreground-only mode
      fgOnlyMode = 0; // set it back to normal condition
      fflush(stdout);
      char* message = "Exiting foreground-only mode\n";
      write(1, message, 29);
      fflush(stdout);
      write(1, ": ", 2);
   }
}


/********************************************
 * This function allows shell to ignore commands
 * which begin with #. Blank line should do nothing
 ********************************************/
int commentCheck (char* input) {
   int isCommandBlank = 1;
   if (input[0] == '#' || input[0] == '\n') { // is it a comment or a blank line
      isCommandBlank = 0;
   }
   return isCommandBlank;
}


/************************************************
 * This function gets the command from user and 
 * parses it into struct command
 ************************************************/
struct commands* getCommand() {
   struct commands *command = malloc(sizeof(struct commands));
   char input[MAX_COMMAND_LENGTH]; // Stores user input
   char* saveptr;
   int comment = 1;
   int childStatus;
   int condition = 1;

   struct sigaction SIGINT_action = {0}; // initialize SIGINT_action struct to be 0
   SIGINT_action.sa_handler = SIG_IGN; // parent will ignore ^C signal
   sigfillset(&SIGINT_action.sa_mask); // Block all catchable signals while SIGINT is running
   SIGINT_action.sa_flags = 0; // No flags set
   sigaction(SIGINT, &SIGINT_action, NULL) ;

   struct sigaction SIGTSTP_action = {0}; // initialize SIGTSTP_action struct to be 0
   SIGTSTP_action.sa_handler = handle_SIGTSTP; // register handle_SIGTSTP as the signal handler
   sigfillset(&SIGTSTP_action.sa_mask); // Block all catchable signals while SIGTSTP is running
   SIGTSTP_action.sa_flags = SA_RESTART; // No flags set
   sigaction(SIGTSTP, &SIGTSTP_action, NULL) ;
   while(condition) {
      do {
         command->argNum = 0; // holds number of arguments 
         command->isBackground = 0;   
         command->inputFile = NULL;
         command->outputFile = NULL;
         printf(": "); // : symbol as a prompt for each comamnd line
         fflush(stdout); // flush out the output buffer
         fflush(stdin);
         fgets(input, MAX_COMMAND_LENGTH, stdin); // gets command from user
         comment = commentCheck(input);
      } while(comment == 0);
      strcpy(input, expand(input)); // check for $$ and overwrite input

      // Remove newline from input
      size_t i = strlen(input)-1;
      if (input[i] == '\n') {
         input[i] = '\0';
      }
//   printf("%s\n", input);
//   fflush(stdout);
   

      char* token = strtok_r(input, " ", &saveptr); // get the first token from input
      while (token != NULL) { // if token is not NULL
         // is it input redirection?
         if (strcmp(token, "<") == 0) { // is token <?
            token = strtok_r(NULL, " ", &saveptr); // token after < is input file
            command->inputFile = calloc(strlen(token) + 1, sizeof(char));
            strcpy(command->inputFile, token); // coppy token into inputFile
         }
         // Is it output redirection?
         if (strcmp(token, ">") == 0) {  // is token >
            token = strtok_r(NULL, " ", &saveptr); // token after > is output file
            command->outputFile = calloc(strlen(token + 1), sizeof(char)); // callocate memory for outputFIle with size of token
            strcpy(command->outputFile, token); // copy token into outputFile
         }
         // Is it in backgound?
         if(strcmp(token, "&") == 0) { // is token &?
            command->isBackground = 1; // 1 mean it's in back ground mode
         }
         if(command->inputFile == NULL && command->outputFile == NULL) {
            command->args[command->argNum] = token; // store token into args
            command->argNum++; // increment argNum by 1
         }
         token = strtok_r(NULL, " ", &saveptr);
      }
  
      // remove & from command arg
      if (strcmp(command->args[command->argNum - 1], "&") == 0) {
         command->argNum--;
      }
      command->args[command->argNum] = NULL;
/* 
   for(int i = 0; i < command->argNum; i++) {
      printf("args[%d] = %s ", i, command->args[i]);
      fflush(stdout);
   }
      printf("\n");
   printf("inputFile = %s\n", command->inputFile);
   printf("outputFile = %s\n", command->outputFile);
*/   
      if((strcmp(command->args[0], "cd")) == 0 || (strcmp(command->args[0], "status")) == 0 || (strcmp(command->args[0],"exit")) == 0){
         builtIn(command->isBackground, command->args[0], command->args[1], command->processes, command->processNum, beforeForeground, childStatus);
      }
      else
         nonBuiltIn(command, SIGINT_action, SIGTSTP_action); 
   
      for(int i = 0; i < command->argNum; i++) {
         command->args[i] = NULL;
      }
   }
   return command;
}








































