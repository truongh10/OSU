To compile:	gcc --std=gnu99 -o movies movies.c

