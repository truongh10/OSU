#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "application.c"

int main(int argc, char *argv[]) {
   if (argc < 2) {
      printf ("You must provide the name of the file to process\n");
      printf ("example usage: ./movies movie_sample_1.csv\n");
      return EXIT_FAILURE;
   }
   
   struct movie *movie = processFile(argv[1]);
   int num = movieNum(movie);
   printf("Process file %s and parse data for %d movies\n\n",argv[1], num);
//   sortByLanguages(movie, "Hindi");
   processChoice(movie);
   return 0;
}

