#include <stdlib.h>
#include <assert.h>
#include <string.h>
#include <stdio.h>

/* Struct for movie information
 */
struct movie {
   char* title;
   int year;
   char* languages;
   double rating;
   int count;
   struct movie* next;
};


/* Parse the current line which is space delimited and created
 * a movie struct with the data in this line
 */
struct movie *createMovie(char *currLine) {
   struct movie *currMovie = malloc(sizeof(struct movie));
   char * saveptr;
   //The first token is the title
   char *token = strtok_r(currLine, ",", &saveptr);
   currMovie->title = calloc(strlen(token) + 1, sizeof(char));
   strcpy(currMovie->title, token);

   // The next token is the year
   token = strtok_r(NULL, ",", &saveptr);
   currMovie->year = atoi(token); // Convert string token to int year

   // The next token is the languages
   token = strtok_r(NULL, ",", &saveptr);
   currMovie->languages = calloc(strlen(token) + 1, sizeof(char));
   strcpy(currMovie->languages, token);

   // The last token is the rating
   token = strtok_r(NULL, "\n", &saveptr);
   char *ptr;
   currMovie->rating = strtod(token, &ptr); // Convert string token to double rating

   // Set the next node to NULL in the newly created movie entry
   currMovie->next = NULL;

   return currMovie;
}

/* Return a linked list of movies by parsing data from
 * each line og the specified file
 */
struct movie *processFile(char* filePath) {
   
   // Open the specifiled file for reading only
   FILE *movieFile = fopen(filePath, "r");

   char * currLine = NULL;
   size_t len = 0;
   ssize_t nread;
   char *token;
   // The head of the linked list
   struct movie *head = NULL;
   // The tail of the linked list
   struct movie *tail = NULL;
   
   // Read the file line by line
   while ((nread = getline(&currLine, &len, movieFile)) != -1) {
      // Get a new movie node corresponding to the current line
      struct movie * newNode = createMovie(currLine);
      // Is this the first node in the linked list
      if (head == NULL) {
         // This is the first node in the linked list
         // Set the head and the tail to this node
         head = newNode;
         tail = newNode;
      }
      else {
         //This is not the first node.
         // Add this node to the list and advance the tail
         tail->next = newNode;
         tail = newNode;
      }
   }
   free(currLine);
   fclose(movieFile);
   return head;
}

/*
 * This function returns number of movies in the file
 */
int movieNum(struct movie *movie) {
   int count = 0;
   while (movie != NULL) {
      count++;
      movie = movie->next;
   }
   return count-1;
}

/*
 * Print movies by years
 */
void printMovieByYear(struct movie* yMovie, int j){
   int p = 0;
   
   //iterate though the list and find all movies in a specific year
   while(yMovie != NULL) {
      // If year of movie matches input from user(year), print that movie
      if (yMovie->year == j) {
         printf("%s\n", yMovie->title);
         p = 1;
      }
      yMovie = yMovie->next;
   }
   if (p == 0)
      printf("No data about movies released in the year %d", j);
}


/*
 * Print the highest rated movies for each year
 */
void sortByRate(struct movie *rMovie) {
   // year is 4 digit input, so it ranges from 1000 to 9999
   // For each year from 1000 to 9999. find movies that are released during those years.
   for (int i = 1000; i <= 9999; i++) {
      struct movie *tmp = rMovie;
      struct movie *r = NULL;
      struct movie *max =NULL;
      while (tmp != NULL) {
         if (tmp->year == i) {
            r = tmp;
            // iterate through the list to find movies in the same year and compare their ratings
            // then print the max rated movie for each year
            while (r != NULL) {
               if (r->year == tmp->year) {
                  if (r->rating >= tmp->rating) {
                     max = r;
                  }
                  else if (r->rating < tmp->rating) {
                     max = tmp;
                  }
               }
                  r = r->next;
            }
         printf("%d %f %s\n", max->year, max->rating, max->title);
         break;
         }
         else if (tmp->year != i) tmp = tmp->next;
      }
   }
}

/*
 * This function prints all the movies based on the input(language) from the user
 */
void sortByLanguages(struct movie* lMovie, char *s) {
   struct movie* tmp = lMovie;
   int p = 0;
   
   // iterate through the list
   while (tmp != NULL) {
      char* saveptr = NULL, *saveptr1 = NULL, *token = NULL, *substring = NULL;
         //tokenize the language string of each movie and store in token; delimiters []
         while(token = strtok_r(tmp->languages, "[]", &saveptr)) {
            // Split the string into substring
            substring = strtok_r(token, ";\n", &saveptr1);
	    // Compare substring to input. if equal, print movie and year
 	    while (substring != NULL) {
               if (strcmp(substring,s) == 0){	// strcmp returns 0 if both strings substring and s are equal
                  printf("%d %s\n", tmp->year, tmp->title);
                  p = 1;
               }

               substring = strtok_r(NULL, ";\n", &saveptr1);
            }                       
            break;
            }
      tmp = tmp->next;
   }
   if (p == 0) printf("No data about movies released in %s\n", s);
}

/*
 * This function prints the options to screen
 */
void printOptions() {
   printf("1. Show movies released in the specified year\n");
   printf("2. Show highest rated movie for each year\n");
   printf("3. Show the title and year of release of all movies in a specific language\n");
   printf("4. Exit from the program\n");
}

/*
 * This function asks user for to pick their option and process it
 */
void processChoice(struct movie* movie) {
   int repeat = 1; 
   int choice;
   int year;
   char *language;
  
   do {
      printOptions();
      printf("\nEnter a choice from 1 to 4: ");
      scanf("%d", &choice);
   
      switch(choice) {
         // Show movies in specific year
         case 1:
            printf("Enter the year for which you want to see movies: ");
            scanf("%d", &year);
            printMovieByYear(movie, year);
            printf("\n");
            break;
         // show the highest rated movie for each year
         case 2:
            sortByRate(movie);
            printf("\n");
            break;
         // Show title and year of all movies in a specific language
         case 3:
            printf("Enter the language for which you want to see movies: ");
            scanf("%s", language);
            sortByLanguages(movie, language);
            printf("\n");
            break;
         // Exit the Program
         case 4:
            repeat = 0;
            break;
         // Re-print options if unvalid input
         default:
            printf("Enter an in correct choice. Try again.\n");
            repeat = 1;
      }           
   } while (repeat);
}





















