Sorry that my program results a seg fault.

I tried my best but still don't know what's wrong with it.

I'll take whatever you give me.
