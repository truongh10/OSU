/***************************************
 * Program: Linked List implementation
 * Date: 6/9/19
 * description: main function
 * Inputs: none
 * Output: none
 **************************************/

#include <iostream>
#include "node.h"
#include "list.h"

using namespace std;

int main() {
	Linked_List_Node *head = new Linked_List_Node;
	Linked_List list;
	list.ask_for_number(head);

//	list.sort_ascending(head, 0, list.get_length()-1);

//	cout << "Your list is: " << list.print();

//	list.clear();










	return 0;
}
